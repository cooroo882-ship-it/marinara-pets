Marinara Shimeji — Ggeubeo v0.7.6

이번 핵심 수정: 자동발화도 '최신 콘보 우선'으로 강제

- 자동발화 / 톡 발화 / 테스트 모두 매 생성 순간 참고방과 최근 메시지를 다시 조회
- 최근 24개를 그냥 한 덩어리로 주는 대신:
  · 최신 6개 = [LATEST CONVERSATION]으로 별도 분리
  · 그 이전 최근 대화 = 보조 배경
- 새 메시지가 생겼으면:
  · 마지막 2~4개 메시지의 실제 구체적 소재를 반드시 반영
  · 오래된 화제로 되돌아가지 않도록 지시
- 새 메시지가 없으면:
  · 예전 화제를 앵무새처럼 재탕하지 않고 캐릭터다운 새 잡담
- 오래된 CHAT SUMMARY가 최신 대화를 덮지 않게 변경
  · 최근 메시지가 충분하면 요약 자체를 프롬프트에서 제외
  · 최근 메시지가 거의 없을 때만 보조로 사용
- 최근 6개 메시지 fingerprint를 기억해서
  · 참고방에 정말 새 대화가 생겼는지 런타임에서 구분
- 테스트 상태에는 '실제 최신 “…”'로 마지막 참고 메시지를 표시
- maxTokens 2048 유지
- 최근 펫 대사 반복 방지 / 한 번 재생성 유지

기존 기능 유지
- 수다 2~6분
- 톡 터치 시 AI 한마디
- 위쪽 고정 후 idle / 쉬기 / zzz
- 긴 말풍선 13~26초
- 오른쪽 🍪 / ⚙ / ☾
- rAF / MutationObserver 없음


Ggeukki test build notes:
- Approved sprites integrated: idle, walk1, walk2, grabbed, hop.
- Temporary placeholder mapping: happy/eat/flop/return use idle, goodbye uses hop, run uses walk1.
- Pet size increased slightly to 118px for a larger set feel.

Compact test2: 320px transparent WebP sprites; duplicate base64 payloads removed; no processed asset folder packaged.


Ggeukki v0.2.0-test1 notes:
- Added dedicated sprites for sleep, happy/petting, coffee commute, and flop.
- Sleep now uses its own sprite instead of flop.
- Added a compact coffee action that occasionally plays during idle roaming.
- Remaining temporary mappings: eat->idle, goodbye->hop, return->idle, run->walk1.


0.2.1-fix:
- Fixed compact sprite table: sleep/happy/coffee/flop were missing from SPRITES and therefore fell back to idle.
- Dedicated sprite assets are now mapped correctly.


0.3.0-coexist:
- Unique root id: mara-shimeji-ggeukki
- Cleanup list contains only Ggeukki versions (no Ggeubeo keys)
- CSS/keyframes isolated from Ggeubeo
- Controls shifted one column left
- Starts offset from Ggeubeo


0.3.1:
- Increased Ggeukki display size slightly (118px -> 126px).
- Added dedicated eat sprite so feeding shows a real eating pose instead of looking like idle.


0.3.3:
- Replaced eat pose food from cookie to carrot.
- Changed snack icon from cookie to carrot.
- Maintained coexist-safe separation.


0.3.4:
- Adjusted the carrot food icon to align at the bunny's mouth during the eat animation.
- Removed the duplicate carrot inside the eat sprite by reusing a chewing/idling pose for eat.
- Keeps carrot snack button/icon and coexist-safe separation.


0.3.5:
- Restored a dedicated nibbling eat pose with both paws near the mouth.
- Repositioned the carrot icon lower so it sits near the mouth instead of the eyes.
- Kept the carrot snack button/icon and coexist-safe separation.


0.3.6:
- Reduced the dedicated eat pose so Ggeukki's face does not pop larger only while eating.
- Moved the carrot icon slightly lower/right to better align with the mouth.
- Hid the persistent Z label.


0.3.7:
- Increased Ggeukki normal display size from 126px to 134px so the face/body feel closer to the eat pose.
- Kept the matched eat pose, carrot mouth alignment, and hidden Z label.


0.3.8:
- Enlarged only the idle/basic pose and the cheer/hop pose (the quick “아자!” action).
- Kept the overall pet box size at 134px.
- Preserved the matched eat pose, carrot mouth alignment, and hidden Z label.


0.3.9:
- Rebalanced sprite proportions without changing the 134px pet box.
- Reduced the idle/basic pose slightly.
- Enlarged walk1 and walk2 so walking no longer feels noticeably smaller than idle.
- Kept the enlarged cheer/hop pose and all prior eat/carrot/Z fixes.


0.3.10:
- Corrected the eat pose so it no longer shrinks compared with the default pose.
- Slightly darkened and color-matched the eat pose so it does not look washed out/extra white while eating.
- Kept the current default/base size, natural walk size, enlarged cheer pose, carrot icon, and hidden Z label.


0.3.11:
- Enlarged only the grabbed/lifted pose slightly so it no longer looks smaller than the default pose.
- Preserved all v0.3.10 eat tone/size fixes, walk balance, cheer pose, carrot alignment, and hidden Z label.


0.3.12:
- Added a subtle clarity pass to all Ggeukki art with a small contrast, saturation, and brightness adjustment.
- This is meant to make Ggeukki look a bit crisper and less washed out next to Ggeubeo without changing the accepted sizes or action balance.


0.3.13:
- Smart button coexistence: when Ggeukki runs alone, its three edge buttons sit at the normal right edge.
- When Ggeubeo is also active, Ggeukki automatically shifts its button column left to avoid overlap.
- A lightweight DOM observer detects Ggeubeo being added or removed and repositions the buttons immediately.
- All accepted Ggeukki sprite sizing, clarity, carrot/eat, grab, and Z fixes are preserved.
