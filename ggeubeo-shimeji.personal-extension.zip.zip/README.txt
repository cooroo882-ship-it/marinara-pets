Marinara Shimeji — Ggeubeo v0.7.6

이번 핵심 수정: 자동발화도 '최신 콘보 우선'으로 강제

- 자동발화 / 톡 발화 / 테스트 모두 매 생성 순간 참고방과 최근 메시지를 다시 조회
- 최근 24개를 그냥 한 덩어리로 주는 대신:
  · 최신 6개 = [LATEST CONVERSATION]으로 별도 분리
  · 그 이전 최근 대화 = 보조 배경
- 새 메시지가 생겼으면:
  · 마지막 2~4개 메시지의 실제 구체적 소재를 반드시 반영
  · 오래된 화제로 되돌아가지 않도록 지시
- 새 메시지가 없으면:
  · 예전 화제를 앵무새처럼 재탕하지 않고 캐릭터다운 새 잡담
- 오래된 CHAT SUMMARY가 최신 대화를 덮지 않게 변경
  · 최근 메시지가 충분하면 요약 자체를 프롬프트에서 제외
  · 최근 메시지가 거의 없을 때만 보조로 사용
- 최근 6개 메시지 fingerprint를 기억해서
  · 참고방에 정말 새 대화가 생겼는지 런타임에서 구분
- 테스트 상태에는 '실제 최신 “…”'로 마지막 참고 메시지를 표시
- maxTokens 2048 유지
- 최근 펫 대사 반복 방지 / 한 번 재생성 유지

기존 기능 유지
- 수다 2~6분
- 톡 터치 시 AI 한마디
- 위쪽 고정 후 idle / 쉬기 / zzz
- 긴 말풍선 13~26초
- 오른쪽 🍪 / ⚙ / ☾
- rAF / MutationObserver 없음


0.8.0-coexist:
- Unique root id: mara-shimeji-ggeubeo
- Unique JS instance key
- CSS/keyframes isolated from Ggeukki
- Controls remain in the rightmost column
- Display size: 100px


0.8.1:
- Hid the persistent Z label next to the pet.


0.8.2:
- Increased Ggeubeo display size slightly from 100px to 106px to better match the current Ggeukki base size.
- Kept coexist-safe separation and hidden Z label.


0.8.3:
- Kept the 106px display size from v0.8.2.
- Added a gentle global vertical stretch (scaleY 1.06) to all Ggeubeo sprite art so the character feels less flattened next to Ggeukki.
- This preserves relative size balance across idle, walk, grabbed, eat, and other poses better than changing each state separately.


0.8.4:
- Moved the cookie-eating icon slightly upward so it sits closer to Ggeubeo's mouth while eating.
- Kept the 106px size and the gentle vertical stretch from v0.8.3.
